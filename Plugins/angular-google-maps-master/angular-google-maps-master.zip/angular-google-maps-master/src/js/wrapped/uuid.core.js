angular.module("google-maps.wrapped".ns()).service("uuid".ns(), function() {
  //BEGIN REPLACE
  @@REPLACE_W_LIBS
  //END REPLACE
return UUID;
});